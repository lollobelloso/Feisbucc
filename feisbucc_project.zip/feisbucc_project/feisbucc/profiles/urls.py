from django.urls import path
from . import views

urlpatterns = [
    path('', views.profile, name='profile'),
    path('edit/', views.edit_profile, name='edit_profile'),
    path('send_request/<int:user_id>/', views.send_friend_request, name='send_friend_request'),
    path('accept_request/<int:request_id>/', views.accept_friend_request, name='accept_friend_request'),
    path('reject_request/<int:request_id>/', views.reject_friend_request, name='reject_friend_request'),
    path('users/', views.list_users, name='list_users'),
    path('manage_friendships/', views.manage_friendships, name='manage_friendships'),
]