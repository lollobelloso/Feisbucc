from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .forms import UserProfileForm
from .models import UserProfile, FriendRequest
from posts.models import Post
from django.contrib.auth.models import User

@login_required
def profile(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    user_posts = Post.objects.filter(author=request.user).order_by('-created_at')
    friends = user_profile.friends.all()
    return render(request, 'profiles/profile.html', {
        'user_profile': user_profile,
        'posts': user_posts,
        'friends': friends,
    })

@login_required
def edit_profile(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=user_profile)
        if form.is_valid():
            form.save()
            return redirect('profile')
    else:
        form = UserProfileForm(instance=user_profile)
    return render(request, 'profiles/edit_profile.html', {'form': form})

@login_required
def send_friend_request(request, user_id):
    to_user = get_object_or_404(User, id=user_id)
    from_user = request.user
    if FriendRequest.objects.filter(from_user=from_user, to_user=to_user).exists():
        return redirect('list_users')
    FriendRequest.objects.create(from_user=from_user, to_user=to_user)
    return redirect('list_users')

@login_required
def accept_friend_request(request, request_id):
    friend_request = get_object_or_404(FriendRequest, id=request_id)
    user1 = friend_request.from_user
    user2 = friend_request.to_user
    user1.userprofile.add_friend(user2.userprofile)
    friend_request.delete()
    return redirect('manage_friendships')

@login_required
def reject_friend_request(request, request_id):
    friend_request = get_object_or_404(FriendRequest, id=request_id)
    friend_request.delete()
    return redirect('manage_friendships')

@login_required
def list_users(request):
    users = User.objects.exclude(id=request.user.id)
    return render(request, 'profiles/list_users.html', {'users': users})

@login_required
def manage_friendships(request):
    user_profile = get_object_or_404(UserProfile, user=request.user)
    friend_requests = FriendRequest.objects.filter(to_user=request.user)
    friends = user_profile.friends.all()
    return render(request, 'profiles/manage_friendships.html', {
        'friends': friends,
        'friend_requests': friend_requests,
    })