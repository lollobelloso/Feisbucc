from django.contrib import admin
from .models import UserSettings

admin.site.register(UserSettings)